/*********************************************************************
 *
 *  Aufgabe 405b
 *
 *  Realisieren Sie nun die Berechnung der n-ten Q-Zahl in rekursiver
 *  Form, indem Sie die Funktion
 *
 *    int qRekursiv(int n)
 *
 *  implementieren. Wiederum gibt der Parameter n die Nummer der
 *  Q-Zahl an, die Ihre Funktion berechnen und als Rückgabewert an
 *  main zurückgeben soll. Die Funktion main selbst befindet sich wie
 *  in der vorherigen Teilaufgabe in einer anderen Datei.
 *
 *********************************************************************/


#include <stdio.h>


int qRekursiv(int n)
{
	if (n <= 2) {
		return 1;
	}
	int num_1;
	int num_2;
	num_1 = qRekursiv(n - 1);
	num_2 = qRekursiv(n - 2);
	return qRekursiv(n - num_1) + qRekursiv(n - num_2);
}
