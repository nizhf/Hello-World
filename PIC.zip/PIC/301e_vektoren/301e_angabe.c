/*********************************************************************
 *
 *  Aufgabe 301e
 *
 *  Nachfolgendes Programm berechnet die Summe zweier
 *  dreidimensionaler Vektoren.
 *
 *  Verändern Sie das Programm nun so, dass es das Skalarprodukt
 *  (inneres Produkt) der beiden Vektoren berechnet anstatt der
 *  Summe. Geben Sie den Wert des Skalarprodukts mit folgendem Text in
 *  einer eigenen Zeile aus:
 *
 *    "Das Skalarprodukt betraegt x.xx."
 *
 *  Das Ergebnis sollen Sie an Stelle von x.xx mit exakt zwei
 *  Nachkommastellen ausgeben. Obiger Zeile soll eine
 *  Leerzeile vorausgehen. Beachten Sie dazu bitte die Ausgabe der
 *  Referenzlösung.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int z;              /* Laufvariablen für den Zeilenindex */
	double vektor1[3], vektor2[3];  /* Die beiden Summanden */
	//double vektorS[3];  /* Das Ergebnis der Vektoraddition */
	double product = 0;


	/*
	 * Vektoren einlesen
	 */

	printf("Erster Vektor\n");
	for (z = 0; z < 3; ++z)
	{
		printf("Element %i: ", z+1);
		scanf("%lf", &vektor1[z]);
	}

	printf("\n");
	printf("Zweiter Vektor\n");
	for (z = 0; z < 3; ++z)
	{
		printf("Element %i: ", z+1);
		scanf("%lf", &vektor2[z]);
	}


	/*
	 * Summenvektor berechnen
	 */

	/*for (z = 0; z < 3; ++z)
	{
		vektorS[z] = vektor1[z] + vektor2[z];
	}*/


	/*
	 * Summenvektor ausgeben
	 */

	printf("\n");
	/*printf("Summenvektor\n");

	for (z = 0; z < 3; ++z)
	{
		printf("  %.2lf\n", vektorS[z]);
	}*/

	for (z = 0; z < 3; z++) {
		product += vektor1[z] * vektor2[z];
	}
	printf("Das Skalarprodukt betraegt %.2lf.\n", product);
}
