/*********************************************************************
 * 
 *  Aufgabe 204d
 *
 *  Schreiben Sie ein Programm, mit dem der Benutzer prüfen kann, ob
 *  ein bestimmtes Jahr ein Schaltjahr ist. Dazu liest es erst eine
 *  Jahreszahl vom Benutzer ein, prüft dann, ob dieses Jahr ein
 *  Schaltjahr war, und informiert den Benutzer zuletzt über das
 *  Ergebnis. Berücksichtigen Sie folgende Regeln für das Schaltjahr:
 *
 *    - Ein Jahr, dessen Jahreszahl durch 4 teilbar ist, 
 *      ist ein Schaltjahr ...
 *    - ..., außer wenn die Jahreszahl durch 100 teilbar ist.
 *    - Ist die Jahreszahl durch 400 teilbar, dann ist das
 *      entsprechende Jahr aber trotzdem ein Schaltjahr 
 *      (z.B. 1900 ist kein Schaltjahr, 2000 ist ein Schaltjahr).
 *    - Das angenommene Jahr 0 war kein Schaltjahr.
 *
 *  Die Ein- und Ausgaben des Programms sind bereits vorgegeben. Sie
 *  müssen lediglich die Schaltjahresberechnung hinzufügen; benutzen
 *  Sie dazu den Modulo-Operator. Speichern Sie dann das Ergebnis
 *  Ihrer Berechnung in der Variablen istSchaltjahr ab. Sie soll 1
 *  (wahr/true) sein, wenn das eingegebene Jahr ein Schaltjahr war und
 *  0 (falsch/false), wenn das eingegebene Jahr kein Schaltjahr war.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	/* Vom Benutzer eingegebene Jahreszahl. */
	int jahr = 0;
	/* 1, falls jahr ein Schaltjahr ist.
		 0, falls jahr kein Schaltjahr ist. */
	int istSchaltjahr = 0;


	printf("Jahreszahl: ");
	scanf("%i", &jahr);

	/* Berechnen Sie hier, ob jahr ein Schaltjahr ist. */
	if (jahr == 0) 
		istSchaltjahr = 0;
	else if (jahr % 400 == 0)
		istSchaltjahr = 1;
	else if (jahr % 100 == 0)
		istSchaltjahr = 0;
	else if (jahr % 4 == 0)
		istSchaltjahr = 1;
	else istSchaltjahr = 0;

	
	if (istSchaltjahr == 1)
	{
		printf("%i war ein Schaltjahr.\n", jahr);
	}

	else
	{
		printf("%i war kein Schaltjahr.\n", jahr);
	}
}
