/*********************************************************************
 *
 *  Aufgabe 208d
 *
 *  Der folgende Code zeigt ein einfaches Menü. Es wird typischerweise
 *  mit einer do-while-Schleife realisiert.
 *
 *  Schreiben Sie den Code so um, dass er eine for-Schleife anstelle
 *  der do-while-Schleife benutzt.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	char antwort = 'e';

	
	for (antwort = 'e'; antwort != 'd' && antwort != 'D'; )
	{
		printf("\n");
		printf("Menü\n");

		printf("a)  Mensa Innenstadt\n");
		printf("b)  Steinheil\n");
		printf("c)  Thai Magie\n");
		printf("d)  Beenden\n");
		printf("\n");

		printf("Bitte wählen Sie eine Aktion aus: ");
		scanf(" %c", &antwort);

		if(antwort == 'a' || antwort == 'A')
		{
			printf("Es gibt Krautspaetzle. Verdauungsschlaf am Nachmittag.\n");
		}
		
		else if (antwort == 'b' || antwort == 'B')
		{
			printf("Grosses Schnitzel mit Bratkartoffeln.\n");
		}

		else if (antwort == 'c' || antwort == 'C')
		{
			printf("Menue 503. Es lebe die Mikrowelle.\n");
		}

	} 
}
