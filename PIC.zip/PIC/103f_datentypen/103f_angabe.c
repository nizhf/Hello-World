/*********************************************************************
*
*  Aufgabe 103f
*
*  Schreiben Sie Ihren Code von Aufgabe 102 so um, dass Sie jeden
*  Wert nicht direkt ausgeben. Stattdessen legen Sie zuerst für alle
*  drei Daten je eine eigene Variable mit einem passenden Datentyp an
*  und weisen ihnen den entsprechenden Wert zu. Geben Sie
*  anschließend die Variablen mit printf aus. (Beachten Sie dabei,
*  dass in C alle Variablen am Anfang des Programms angelegt
*  (definiert) werden müssen.) Benutzen Sie für diese Aufgabe die
*  Datentypen char, double und int.
*
*********************************************************************/


#include <stdio.h>


int main()
{
	int a;
	double b;
	char c;

	a = 42;
	b = 14.21;
	c = 'A';

	printf("%d\n", a);
	printf("%.2lf\n", b);
	printf("%c\n", c);
}
