/*********************************************************************
 *
 *  Aufgabe 306f
 *
 *  Für diese Teilaufgabe ist folgender etwas veränderter Code
 *  gegeben. Er fragt in einer Schleife fortlaufend Studenten ab, bis
 *  der Benutzer abbricht. Jedoch speichert er nur den zuletzt
 *  eingegebenen Datensatz. Sie sollen den Code nun so ergänzen, dass
 *  er eine Liste von Studenten speichert und diese Liste abschließend
 *  ausgibt.
 *
 *  Um nun viele Studenten in einer Liste speichern zu können,
 *  verändern Sie bitte den Code wie folgt:
 *
 *   1. Legen Sie ein Feld an, das 700 Elemente vom Typ struct Student
 *      aufnehmen kann.
 *
 *   2. Speichern Sie alle vom Benutzer eingegebenen Datensätze (Daten
 *      eines Studenten) fortlaufend in diesem Feld.
 *
 *   3. Erweitern Sie die letzte printf-Anweisung um Code, der in
 *      einer Schleife alle eingegebenen Studenten wieder tabellarisch
 *      ausgibt. Die Formatzeichenkette dieser printf-Anweisung soll
 *      dabei unverändert bleiben.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{

	/* Datentyp für alle Daten zu einem Studenten (Datensatz) */
	struct Student
	{
		char nachname[21];
		int termin;      /* Nummer der Tutorübung (1-8) */
	};

	/* Variable, die die Daten zu einem Studenten (Datensatz) speichert.
		 (Vom Datentyp struct Student) */
	struct Student stud[700];

	char antwort = 0;		/* Zum Speichern einer j/n- (Ja/Nein-) Antwort */
	int i = 0;

	do
	{
		/* Daten des Studenten einlesen und überprüfen */
		printf("Nachname: ");
		scanf("%20s", stud[i].nachname);

		printf("Terminnummer der Tutorübung: ");
		scanf("%i", &stud[i].termin);
		if (stud[i].termin < 1 || stud[i].termin > 8)
		{
			printf("Bitte wählen Sie eine Terminnummer zwischen 1 und 8.\n");
			return 1;
		}

		printf("Wollen Sie einen weiteren Studenten eingeben (j/n): ");
		scanf(" %c", &antwort);
		i++;
	} while (antwort != 'n' && antwort != 'N' && i < 700);


	printf("\n\nListe:\n");
	printf("------\n\n");

	for (int j = 0; j < i; j++)
		printf("%-20s  |  %i\n", stud[j].nachname, stud[j].termin);
}
