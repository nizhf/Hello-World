/*********************************************************************
 *
 *  Aufgabe 4
 * 
 *  Ihr Programm soll eine Liste von Studenten formatiert am
 *  Bildschirm ausgeben. Wir haben bereits die main-Funktion, welche
 *  die Liste generiert, in einer anderen Datei implementiert.
 *  Schreiben Sie nun lediglich die Funktion "ausgeben".
 *
 *  Dazu geben Sie zuerst die Titelzeile der Tabelle aus, sowie eine
 *  gestrichelte Linie darunter:
 *
 *    "Nummer | Vorname         | Nachname        | Semester"
 *    "-------|-----------------|-----------------|---------"
 *
 *  Als nächstes geben Sie die Liste in umgekehrter (!) Reihenfolge
 *  aus. Die Nummer ist dabei die Zeilennummer des Eintrags (also eine
 *  Zahl zwischen 20 und 1). Vorname, Nachname und Semester ergeben
 *  sich aus den Einträgen des Felds. Der Formatstring in printf für
 *  eine Tabellenzeile lautet "%6i | %-15s | %-15s | %8i\n".
 *
 *  Beachten Sie bitte unbedingt die Ausgabe der Referenzlösung!
 *
 *********************************************************************/


#include <stdio.h>


/*
 * Datensatz der Tabelle
 */

struct Student {
  char vorname[16];
  char nachname[16];
  int semester;
};


/*
 * Gibt die Liste listeStundenten in umgekehrter Reihenfolge mit
 * Zeilennummer aus.
 */
void ausgeben(struct Student listeStudenten[20])
{

}
