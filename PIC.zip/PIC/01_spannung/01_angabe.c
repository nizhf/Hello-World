/*********************************************************************
 *
 *  Aufgabe 1
 *
 *  Ihr Programm soll ein Spannungswert (in Volt) eingelesen und dann
 *  in der entsprechenden Kurznotation V, kV, oder MV ausgeben. Der
 *  Wert soll in V ausgegeben werden, falls der Wert kleiner als 100 V
 *  ist. In kV soll er ausgegeben werden, falls der Wert kleiner als
 *  100000 V ist, und in MV, falls der Wert größer oder gleich 100000
 *  V ist.
 *
 *
 *  Sie fragen also zuerst eine Zahl mit der Aufforderung
 *
 *    "Bitte geben Sie einen Spannungswert ein (in V): "
 *
 *  ab. Geben Sie dann je nach Größe des Wertes
 *
 *    "Die Spannung betraegt x.x V."
 *
 *  oder
 *
 *    "Die Spannung betraegt y.y kV."
 *
 *  oder
 *
 *    "Die Spannung betraegt z.z MV."
 *
 *  aus. Die Ausgabe soll exakt eine Nachkommastelle
 *  besitzen. Beachten Sie bitte auch die Ausgabe der Referenzlösung!
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
float sp;
printf("Bitte geben Sie einen Spannungswert ein (in V):\n");
scanf("%f\n", &sp);
if (sp >= 500000) {
	sp = sp / 1000000;
	printf("Die Spannung betraegt %.1f", sp);
	printf(" MV.\n");
	}
else if (sp >= 500) {
	sp = sp / 1000;
	printf("Die Spannung betraegt %.1f", sp);
	printf(" kV.\n");
	}
else {
	printf("Die Spannung betraegt %.1f", sp);
	printf(" V.\n");
}
return 0;
}
