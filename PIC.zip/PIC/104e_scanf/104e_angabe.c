/*********************************************************************
*
*  Aufgabe 104e
*
*  In dieser Teilaufgaben schreiben Sie ein einfaches Programm, das
*  das typische Zusammenspiel zwischen Ein- und Ausgabe zeigt. Ihr
*  Programm soll eine Gleitkommazahl vom Benutzer einlesen und als
*  Nächstes wieder ausgeben. Der Quellcode ist soweit fertig; es
*  fehlt lediglich noch eine scanf-Anweisung. Bitte ergänzen Sie das
*  Programm geeignet.
*
*********************************************************************/


#include <stdio.h>


int main()
{
	double zahl = 0.0;
	printf("Zahl: ");

	/* Fügen Sie hier Ihre scanf-Anweisung ein. */
	scanf("%lf\n", &zahl);

	printf("Sie haben %.2lf eingegeben.\n", zahl);
}
