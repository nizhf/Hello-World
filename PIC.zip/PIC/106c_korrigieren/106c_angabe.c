/*********************************************************************
*
*  Aufgabe 106c
*
*  Der folgende Code enthält vier typische Fehler. Nur einen kann
*  bereits der Compiler finden, die verbleibenden drei sind für den
*  Compiler dagegen unsichtbar. (Selbst erfahrene Programmierer
*  schreiben fehlerhaften Code. Deswegen ist es wichtig, das
*  systematische Suchen von Programmierfehlern zu üben.)
*
*  Korrigieren Sie den Code. Vergleichen Sie dazu das Verhalten des
*  fehlerhaften Programms (106c_angabe.c) mit der korrekten
*  Musterlösung (106c_loesung). Ihre Ausgabe muss identisch mit der
*  Ausgabe dieser Referenz sein!
*
*********************************************************************/


#include <stdio.h>


int main()
{
	int i = 0;
	printf("Bitte geben Sie eine ganze Zahl ein: ");
	scanf("%d", &i);
	printf("Die eingegebene Zahl war %d.\n", i);
}
