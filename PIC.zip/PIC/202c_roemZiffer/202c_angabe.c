/*********************************************************************
 *
 *  Aufgabe 202c
 *
 *  Das folgende Programm übersetzt eine römische Zahl, die nur aus
 *  einem einzelnen Zeichen besteht, in unser (arabisches)
 *  Ziffernsystem. Unten finden Sie die Übersetzungstabelle.
 *
 *  Schreiben Sie das Programm so um, dass es die switch-Verzweigung
 *  an Stelle der if-else-Verzweigung benutzt.
 *
 *  Die folgende Tabelle zeigt die Entsprechungen der römischen
 *  Ziffern:
 *
 *    I     1
 *    V     5
 *    X    10
 *    L    50
 *    C   100
 *    D   500
 *    M  1000
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	char zeichen = 0;


	printf("Einstellige roemische Ziffer: ");
	scanf("%c", &zeichen);

	switch (zeichen) {
	case 'I':
		printf("Der Wert betraegt 1.\n");
		break;
	case 'V':
		printf("Der Wert betraegt 5.\n");
		break;
	case 'X':
		printf("Der Wert betraegt 10.\n");
		break;
	case 'L':
		printf("Der Wert betraegt 50.\n");
		break;
	case 'C':
		printf("Der Wert betraegt 100.\n");
		break;
	case 'D':
		printf("Der Wert betraegt 500.\n");
		break;
	case 'M':
		printf("Der Wert betraegt 1000.\n");
		break;
	default:
		printf("Es wurde keine roemische Ziffer eingegeben.\n");
		break;
}
	/*
	if (zeichen == 'I')
	{
		printf("Der Wert betraegt 1.\n");
	}
	else if (zeichen == 'V')
	{
		printf("Der Wert betraegt 5.\n");
	}
	else if (zeichen == 'X')
	{
		printf("Der Wert betraegt 10.\n");
	}
	else if (zeichen == 'L')
	{
		printf("Der Wert betraegt 50.\n");
	}
	else if (zeichen == 'C')
	{
		printf("Der Wert betraegt 100.\n");
	}
	else if (zeichen == 'D')
	{
		printf("Der Wert betraegt 500.\n");
	}
	else if (zeichen == 'M')
	{
		printf("Der Wert betraegt 1000.\n");
	}
	else
	{
		printf("Es wurde keine roemische Ziffer eingegeben.\n");
	}
	*/
}
