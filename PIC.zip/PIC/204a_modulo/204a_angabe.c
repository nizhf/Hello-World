/*********************************************************************
 * 
 *  Aufgabe 204a
 *
 *  Lesen Sie hierzu bitte die Angabe zu Aufgabe 204 auf dem
 *  Arbeitsblatt 2 im Internet.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int d1, d2;         /* Die Operanden */
	int division, rest; /* Beide Kompontenten des Ergebnisses */

	/* Operanden einlesen */
	printf("Dividend: ");
	scanf("%i", &d1);
	printf("Divisor: ");
	scanf("%i", &d2);

	/* Berechnungen durchführen */
	division = d1 / d2;
	rest = d1 % d2;

	/* Ergebnis ausgeben */
	printf("Ganzzahldivision: %i\n", division);
	printf("Rest: %i\n", rest);
}
