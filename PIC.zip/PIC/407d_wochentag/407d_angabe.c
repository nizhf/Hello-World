/*********************************************************************
 *
 *  Aufgabe 407d
 *
 *  Die main-Funktion ist bereits vorgegeben. Lassen Sie diese bitte
 *  unbedingt unverändert. Implementieren Sie vielmehr die vier
 *  Funktionen datumEinlesen, tageDurchJahr, tageDurchMonat und
 *  istSchaltjahr, deren Gerüst unten bereits vorgegeben ist. Beachten
 *  Sie bitte die Kommentare, die vor jeder Funktion deren Aufgabe
 *  erklären.
 *
 *  Lassen Sie das vorgegebene Grundgerüst unverändert. Behalten Sie
 *  insbesondere die Funktionsdefinitionen und deren Reihenfolge
 *  bei. Lesen Sie auch die Hinweise auf dem Arbeitsblatt, ehe Sie
 *  diese Aufgabe bearbeiten.
 *
 *********************************************************************/


#include <stdio.h>


/* Feld zur Zuordnung zwischen der Nummer eines Wochentags und dessen
	 Namen (Zeichenfolge) */
const char *wochentage[7] = {
	"Sonntag",
	"Montag",
	"Dienstag",
	"Mittwoch",
	"Donnerstag",
	"Freitag",
	"Samstag"
};

/* Feld zur Zuordnung zwischen der Nummer eines Monats und der Anzahl
	 der Tage in diesem Monat */
const int monatstage[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};


/*
 * Vorwärtsdeklarationen von Funktionen
 */
int datumEinlesen(int *jahr, int *monat, int *tag);
int tageDurchJahr(int jahr);
int tageDurchMonat(int monat, int jahr);
int istSchaltjahr(int jahr);


int main()
{
	int jahr = 0, monat = 0, tag = 0;  /* Eingegebenes Datum */
	int tage = 0;          /* Tage die seit dem 1.1.0 vergangen sind */


	/*
	 * Abfragen des Datums
	 */
	if( !datumEinlesen(&jahr, &monat, &tag) )
	{
		return 1;
	}


	/*
	 * Berechnung der seit dem 1.1.0 vergangenen Tage
	 */
	tage = tageDurchJahr(jahr);
	tage += tageDurchMonat(monat, jahr);
	tage += tag - 1;  /* Anzahl der Tage durch die Tagesangabe */


	/*
	 * Ausgabe des Wochentags
	 */

	printf("Der %02i.%02i.%i ist ein %s.\n",
		tag, monat, jahr, wochentage[tage%7]);

	return 0;
}


/*
 * datumEinlesen
 *
 * Diese Funktion liest das Datum ein und speichert die Eingabe in den
 * mit jahr, monat und tag referenzierten Variablen. War die Eingabe
 * des Benutzers korrekt, gibt die Funktion 1 (wahr) zurück. Macht der
 * Benutzer eine falsche Eingabe (z.B. 29.2.2001 oder Monat > 12),
 * dann bricht die Funktion sofort ab und gibt 0 (falsch) zurück.
 */
int datumEinlesen(int *jahr, int *monat, int *tag)
{
	printf("Jahr: ");
	scanf("%d", jahr);
	if (*jahr < 0)
		return 0;
	printf("Monat: ");
	scanf("%d", monat);
	if (*monat > 12 || *monat < 1)
		return 0;
	printf("Tag: ");
	scanf("%d", tag);
	if (*tag < 1 || *tag > 31)
		return 0;
	if (istSchaltjahr(*jahr) && *monat == 2 && *tag > 29)
		return 0;
	if (!istSchaltjahr(*jahr) && *monat == 2 && *tag > 28)
		return 0;
	if ((*monat == 4 || *monat == 6 || *monat == 9 || *monat == 11) && *tag > 30)
		return 0;
	return 1;
}


/*
 * tageDurchJahr
 *
 * Diese Funktion gibt die Anzahl der Tage zurück, die seit dem 1.1.0
 * bis zum Ende des Jahres vor der Jahresangabe jahr vergangen sind,
 * also die Anzahl an Tagen, die allein sich dadurch ergibt das man die
 * Jahreszahl angibt.
 */
int tageDurchJahr(int jahr)
{
	int countDay = 0;
	int yearDay = 365;
	for (int i = 0; i < jahr; i++) {
		if (istSchaltjahr(i))
			countDay += (yearDay + 1);
		else
			countDay += yearDay;
	}
	return countDay;
}


/*
 * tageDurchMonat
 *
 * Diese Funktion gibt die Anzahl der Tage zurück, die im Jahr jahr
 * seit Jahresbeginn bis zum Ende des Monats vor der Monatsangabe
 * monat vergangen sind, also die Anzahl an Tagen, die sich dadurch
 * ergibt, dass man einen bestimmten Monat angibt. Der Parameter jahr
 * ermöglicht der Funktion zwischen Schaltjahren und Nicht-Schaltjahren
 * zu unterscheiden.
 */
int tageDurchMonat(int monat, int jahr)
{
	int monthDay[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	int countDay = 0;
	for (int i = 0; i < monat - 1; i++) {
		if (istSchaltjahr(jahr) && i == 1)
			countDay += (monthDay[i] + 1);
		else
			countDay += monthDay[i];
	}
	return countDay;
}


/*
 * istSchaltjar
 *
 * Berechnet, ob jahr ein Schaltjahr war. Trifft dies zu, gibt
 * die Funktion 1 zurück, andernfalls 0.
 */
int istSchaltjahr(int year)
{
	if (year == 0)
		return 0;
	else if (year % 400 == 0)
		return 1;
	else if (year % 100 == 0)
		return 0;
	else if (year % 4 == 0)
		return 1;
	else return 0;
}
