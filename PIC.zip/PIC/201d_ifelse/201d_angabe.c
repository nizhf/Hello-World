/*********************************************************************
 * 
 *  Aufgabe 201d
 *
 *  Das folgende Programm prüft, ob eine eingegebene Zahl gleich Null
 *  ist. Ändern Sie das Programm nun so ab, dass es folgende Logik
 *  umsetzt: Wenn zahl größer Null ist, dann soll das Programm
 *
 *    "Sie haben eine Zahl groesser Null eingegeben."
 *
 *  ausgeben. Andernfalls, wenn zahl gleich Null ist, dann soll das
 *  Programm
 *
 *    "Sie haben Null eingegeben."
 *
 *  ausgeben. Andernfalls soll das Programm
 *
 *    "Sie haben eine Zahl kleiner Null eingegeben."
 *
 *  ausgeben. Setzen Sie bitte genau die Struktur um, welche durch die
 *  Wörter wenn, dann und andernfalls vorgegeben ist.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int zahl = 0;

	printf("Bitte geben Sie eine ganze Zahl ein: ");
	scanf("%i", &zahl);

	if (zahl == 0) 
	{
		printf("Sie haben Null eingegeben.\n");

	}
	else if (zahl > 0)
	{
		printf("Sie haben eine Zahl groesser Null eingegeben.\n");
	}
	else {
		printf("Sie haben eine Zahl kleiner Null eingegeben.\n");
	}
}
