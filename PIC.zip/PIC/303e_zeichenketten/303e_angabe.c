/*********************************************************************
 *
 * Aufgabe 303e
 *
 * Ergänzen Sie das gegebene Programm am Ende (also nach der letzten
 * printf-Anweisung) um die folgenden beiden Funktionen: Berechnen Sie
 * zuerst die Länge der eingegebenen Zeichenkette und geben Sie diese
 * am Ende mit dem Formatstring
 *
 *   "Laenge der Zeichenkette: %i.\n"
 *
 *  aus. Benutzen Sie dazu nicht die Funktion strlen.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	char eingabe[21];
	int i = 0;
	int count = 0;

	printf("Bitte geben Sie einen Text ein: ");
	scanf("%20s", eingabe);

	printf("# ");
	for(i = 0; i < 21; ++i)
	{
		printf(" %c ", eingabe[i]);
	}
	printf("\n");

	for (i = 0; i < 21; i++) {
		if (eingabe[i] == '\0')
			break;
		count++;
	}
	printf("Laenge der Zeichenkette: %d. \n", count);
}
