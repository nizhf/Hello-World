/*********************************************************************
 *
 *  Aufgabe 401c
 *
 *  Schreiben Sie unten stehendes Programm so um, dass in den
 *  Unterfunktionen nur noch die Umrechnungsformeln verbleiben, alle
 *  printf- und scanf-Aufrufe dagegen in main zu finden sind. Die
 *  Funktionalität soll dabei exakt erhalten bleiben. Zwischen main
 *  und den Unterfunktionen sollen Sie die nötigen Informationen durch
 *  Funktionsparameter und Rückgabewerte austauschen.
 *
 *********************************************************************/


#include <stdio.h>

double fahrenheitToCelsius(double fahrenheit)
{
	return (5.0/9.0 * (fahrenheit - 32.0));

}


double celsiusToFahrenheit(double celsius)
{
	return (9.0/5.0 * celsius + 32.0);
}


int main()
{
	int menue;
	double temperatur;

	do
	{
		/* Menü */
		printf("\n" );
		printf("*****************************************\n");
		printf("* Bitte waehlen Sie eine Umrechnungsart:\n");
		printf("* 1) Grad Celsius in Fahrenheit umrechnen\n");
		printf("* 2) Fahrenheit in Grad Celsius umrechnen\n");
		printf("* 3) Beenden\n");
		printf("*****************************************\n");
		printf("Auswahl: ");
		scanf("%i", &menue);

		/* Temperatur umrechnen */
		switch(menue)
		{
			case 1:
				printf("Temperatur in Grad Celsius: ");
				scanf("%lf", &temperatur);
				printf("Temperatur in Fahrenheit: %.1lf\n", celsiusToFahrenheit(temperatur));
				break;
			case 2:
				printf("Temperatur in Fahrenheit: ");
				scanf("%lf", &temperatur);
				printf("Temperatur in Grad Celsius: %.1lf\n", fahrenheitToCelsius(temperatur));
				break;
		}

	} while (menue != 3);

	return 0;
}
