/*********************************************************************
*
*  Aufgabe 105b
*
*  Das gegebene Programm unten berechnet die Oberfläche einer
*  Kugel. Ihr Programm soll zusätzlich zur Oberfläche auch noch das
*  Volumen der Kugel berechnen. Die mathematische Formel hierfür
*  lautet V = 4/3 pi r³. (Benutzen Sie r*r*r für r³.)
*
*  Fügen Sie die Berechnung in den gegebenen Quellcode ein. Geben Sie
*  am Ende des Programms den Text
*
*    "Volumen: "
*
*  gefolgt vom Wert des Volumens (wieder mit genau zwei
*  Nachkommastellen) in einer eigenen Zeile aus. Beachten Sie dazu
*  bitte auch die Ausgaben des Musterlösungsprogramms. Sie müssen
*  diese identisch nachbilden (Zeichen für Zeichen)!
*
*********************************************************************/


#include <stdio.h>


int main()
{
	const double PI = 3.14159;  /* Kreiskonstante pi */
	double r = 0.0;             /* Radius der Kugel */
	double A = 0.0;             /* Oberfläche der Kugel */
	double V = 0.0;

	/* Radius vom Benutzer einlesen */
	printf("Kugelradius: ");
	scanf("%lf", &r);

	/* Berechnungen durchführen */
	A = 4.0 * PI * r * r;
	V = 4.0 / 3.0 * PI * r * r * r;


	/* Ausgabe des Ergebnisses */
	printf("Radius: %.2lf\n", r);
	printf("Oberflaeche: %.2lf\n", A);
	printf("Volumen: %.2lf\n", V);
}
