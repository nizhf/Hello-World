/*********************************************************************
*
*  Aufgabe 101f
*
*  Der unten stehende Text soll auf dem Bildschirm angezeigt werden.
*  Achten Sie darauf, dass die Ausgabe exakt Zeichen für Zeichen mit
*  der Vorgabe übereinstimmt.
*
*  "Wir programmieren in 'C' (ANSI)."
*  "  a[0] = 1; b = 2; x = 3 * a[0] + b"
*  "Sie sagte: "Ich mag keine Hunde!""
*  "Der Slash ("/") und der Backslash ("\") werden manchmal verwechselt"
*
*  Die äußersten Anführungszeichen in jeder Zeile sind kein Teil der
*  Ausgabe sind, sondern die Begrenzung des auszugebenden Textes.
*  Geben Sie am Ende jeder Zeile auch einen Zeilenumbruch aus.
*
*********************************************************************/


#include <stdio.h>


int main()
{
printf("Wir programmieren in 'C' (ANSI).\n");
printf("  a[0] = 1; b = 2; x = 3 * a[0] + b\n");
printf("Sie sagte: \"Ich mag keine Hunde!\"\n");
printf("Der Slash (\"/\") und der Backslash (\"\\\") werden manchmal verwechselt\n");


}
