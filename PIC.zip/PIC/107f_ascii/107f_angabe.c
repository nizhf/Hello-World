/*********************************************************************
*
*  Aufgabe 107f
*
*  Ihr Programm macht aus einem Großbuchstaben einen
*  Kleinbuchstaben.
*
*  Fragen Sie dazu mit der Aufforderung
*
*    "Bitte geben Sie einen Grossbuchstaben ein: "
*
*  ein Zeichen vom Benutzer ab. Sie müssen nicht prüfen, ob es
*  tatsächlich ein Großbuchstabe ist. Übersetzen Sie diesen
*  Großbuchstaben dann in einen Kleinbuchstaben. Den Kleinbuchstaben
*  geben Sie schließlich in einer eigenen Zeile aus.
*
*  Hinweis: 'a' hat den ASCII-Wert  97.
*           'z' hat den ASCII-Wert 122.
*           'A' hat den ASCII-Wert  65.
*           'Z' hat den ASCII-Wert  90.
*  Die anderen Buchstaben liegen in alphabetischer Reihenfolge
*  dazwischen!
*
*********************************************************************/


#include <stdio.h>


int main()
{
	char c = 'A';
	printf("Bitte geben Sie einen Grossbuchstaben ein: ");
	scanf("%c", &c);
	c = c + 32;
	printf("%c\n", c);
}
