/*********************************************************************
 *
 *  Aufgabe 203a
 *
 *  Schreiben Sie ein Programm, mit dem man eine quadratische
 *  Gleichung lösen kann:
 *
 *    a * x*x + b * x + c = 0
 *
 *  Fragen Sie dazu zuerst die Variablen a, b und c (Gleitkommazahlen)
 *  mit den folgenden drei Aufforderungen vom Benutzer ab:
 *
 *    "a: "
 *    "b: "
 *    "c: "
 *
 *  Berechnen Sie dann die Lösung unter Berücksichtigung der drei
 *  Fälle: Es gibt keine reelle Lösung, eine reelle Lösung (die
 *  doppelte Nullstelle x1_2) und zwei reelle Lösungen (x1 und
 *  x2). Geben Sie je nach Fall einen der folgenden Texte aus:
 *
 *    "Es gibt keine reelle Loesung."
 *    "Die doppelte Nullstelle lautet x1_2."
 *    "Die beiden reellen Loesungen sind x1 und x2."
 *
 *  Geben Sie die Lösung mit genau zwei Nachkommastellen aus.
 *
 *  Hinweis:
 *
 *    Die C-Funktion (in math.h)
 *
 *      erg = sqrt(z);
 *
 *    weist der Variablen erg die positive Wurzel von z zu. Das
 *    funktioniert (natürlich) nur für positive z.
 *
 *********************************************************************/


#include <stdio.h>
#include <math.h>
#define eps 1e-8


int main()
{
	double a = 0.0;
	double b = 0.0;
	double c = 0.0;
	double delta;
	printf("a: ");
	scanf("%lf", &a);
	printf("b: ");
	scanf("%lf", &b);
	printf("c: ");
	scanf("%lf", &c);
	delta = b * b - 4.0 * a * c;
	if (fabs(delta - 0.0) < eps) {
		printf("Die doppelte Nullstelle lautet %.2lf.\n", -b / (2 * a));
	}
	else if (delta > 0) {
		printf("Die beiden reellen Loesungen sind %.2lf und %.2lf.\n", (-b + sqrt(delta)) / (2 * a), (-b - sqrt(delta)) / (2 * a));
	}
	else {
		printf("Es gibt keine reelle Loesung.\n");
	}


}
