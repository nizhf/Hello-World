/*********************************************************************
 *
 *  Aufgabe 206h
 *
 *  Ihr Programm dieser Aufgabe soll das Bitmuster einer ganzen Zahl
 *  (int) ausgeben. Hierfür wenden Sie Bitoperatoren (>> und &) an.
 *
 *  Auf dem Arbeitsblatt 2 im Internet finden Sie den Algorithmus in
 *  verbalisierter Form. Setzen Sie nun den Algorithmus in der Sprache
 *  C um.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int sb;
	int aktBit;
	printf("Geben Sie bitte eine Dezimalzahl ein: ");
	scanf("%d", &sb);
	if (sb < 0) {
		printf("Die Zahl muss groesser gleich Null sein!\n");
	}
	else {
		printf("Die zugehoerige Binaerzahl lautet: ");
		for (int i = 30; i >= 0; i--) {
			aktBit = (sb >> i) & 1;
			printf("%d", aktBit);
		}
		printf("\n");
	}
}
