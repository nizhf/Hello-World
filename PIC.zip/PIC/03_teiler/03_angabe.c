/*********************************************************************
 *
 *  Aufgabe 3
 *
 *  Ihr Programm soll in dieser Aufgabe alle ganzzahligen Teiler einer
 *  positiven ganzen Zahl berechnen. Die main-Funktion ist von uns in
 *  einer anderen Datei geschrieben und beinhaltet bereits alle Ein-
 *  und Ausgaben.
 *
 *  Implementieren Sie nun die Funktion teilerListe, die eine Liste
 *  aller ganzzahligen Teiler größer Null berechnet und einen Zeiger
 *  auf das erste Element der Liste zurückgibt.
 *
 *  Reservieren Sie dazu zuerst mit malloc einen Speicherbereich der
 *  Größe n/2+1. Testen Sie dann alle Zahlen von 1 bis n/2 darauf,
 *  ob sie ein Teiler von n sind. Jede Zahl die ein Teiler von n ist,
 *  schreiben sie fortlaufend in die Liste. (Zwischen den Teilern
 *  dürfen keine "leeren" Listenelemente sein.) Speichern Sie danach
 *  auf den nächsten Listenplatz den Wert 0, an dem die
 *  main-Funktion das Listenende erkennt. Geben Sie abschließend einen
 *  Zeiger auf die Liste zurück.
 *
 *********************************************************************/


#include <stdlib.h>
#include <stdio.h>


/* 
 * n: Zahl, zu der alle ganzzahligen Teiler größer Null ausgegeben
 *    werden sollen.
 */

int *teilerListe(int n)
{
	
}
