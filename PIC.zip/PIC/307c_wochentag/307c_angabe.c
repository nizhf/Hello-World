/*********************************************************************
 *
 *  Aufgabe 307c
 *
 *  Schreiben Sie ein Programm, um den Wochentag an einem bestimmten
 *  Datum zu bestimmen. Berücksichtigen Sie folgende Regeln für das
 *  Schaltjahr. Sie haben diese Bedingungen programmiertechnisch
 *  bereits in Aufgabe 204 umgesetzt.
 *
 *    - Ein Jahr, dessen Jahreszahl durch 4 teilbar ist, ist ein
 *      Schaltjahr ...
 *
 *    - ..., außer wenn die Jahreszahl durch 100 teilbar ist.
 *
 *    - Ist die Jahreszahl durch 400 teilbar, dann ist das
 *      entsprechende Jahr aber trotzdem ein Schaltjahr.
 *      (Beispielsweise ist 1900 kein Schaltjahr, 2000 ist aber ein
 *      Schaltjahr.)
 *
 *  Zusätzlich soll das (fiktive) Jahr 0 kein Schaltjahr und der
 *  1. Januar 00 ein Sonntag gewesen sein.
 *
 *  Fragen Sie zu Beginn das Datum mit
 *
 *    "Jahr: "
 *    "Monat: "
 *    "Tag: "
 *
 *  ab. Überprüfen Sie dessen Korrektheit (Tag und Monat im gültigen
 *  Bereich; Jahr ≥ 0) und brechen Sie bei einer fehlerhaften Eingabe
 *  sofort mit der Meldung
 *
 *   "Falsche Eingabe."
 *
 *  ab. War das eingegebene Datum in Ordnung, geben Sie den Wochentag
 *  mit
 *
 *    "Der xx.xx.xxxx ist ein yyyyyyy."
 *
 *  aus. Dabei ist xx.xx.xxxx das eingegebene Datum, beispielsweise in
 *  der Form 13.01.736, und yyyyyyy der Wochentag, beispielsweise
 *  Donnerstag.
 *
 *  Beachten Sie bitte auch die zusätzlichen Hilfestellungen auf dem
 *  Arbeitsblatt.
 *
 *********************************************************************/


#include <stdio.h>

int isLeapYear(int year);

int main()
{
	int jahr;
	int monat;
	int tag;
	int countDay = 0;
	int monthDay[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	char *weekDay[] = {"Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"};
	int yearDay = 0;

	for (int i = 0; i < 12; i++)
		yearDay += monthDay[i];

	printf("Jahr: ");
	scanf("%d", &jahr);
	if (jahr < 0) {
		printf("Falsche Eingabe.\n");
		return -1;
	}
	printf("Monat: ");
	scanf("%d", &monat);
	if (monat > 12 || monat < 1) {
		printf("Falsche Eingabe.\n");
		return -1;
	}
	printf("Tag: ");
	scanf("%d", &tag);
	if (tag < 1 || tag > 31) {
		printf("Falsche Eingabe.\n");
		return -1;
	}
	if (isLeapYear(jahr) && monat == 2 && tag > 29) {
		printf("Falsche Eingabe.\n");
		return -1;
	}
	if (!isLeapYear(jahr) && monat == 2 && tag > 28) {
		printf("Falsche Eingabe.\n");
		return -1;
	}
	if ((monat == 4 || monat == 6 || monat == 9 || monat == 11) && tag > 30) {
		printf("Falsche Eingabe.\n");
		return -1;
	}

	for (int i = 0; i < jahr; i++) {
		if (isLeapYear(i))
			countDay += (yearDay + 1);
		else
			countDay += yearDay;
	}
	for (int i = 0; i < monat - 1; i++) {
		if (isLeapYear(jahr) && i == 1)
			countDay += (monthDay[i] + 1);
		else
			countDay += monthDay[i];
	}
	countDay += (tag - 1);
	if (tag < 10 && monat < 10)
		printf("Der 0%d.0%d.%d ist ein %s.\n", tag, monat, jahr, weekDay[countDay % 7]);
	else if (tag < 10)
		printf("Der 0%d.%d.%d ist ein %s.\n", tag, monat, jahr, weekDay[countDay % 7]);
	else if (monat < 10)
		printf("Der %d.0%d.%d ist ein %s.\n", tag, monat, jahr, weekDay[countDay % 7]);
	else
		printf("Der %d.%d.%d ist ein %s.\n", tag, monat, jahr, weekDay[countDay % 7]);


}

int isLeapYear(int year) {
	if (year == 0)
		return 0;
	else if (year % 400 == 0)
		return 1;
	else if (year % 100 == 0)
		return 0;
	else if (year % 4 == 0)
		return 1;
	else return 0;
}
