/*********************************************************************
 *
 *  Aufgabe 302c
 *
 *  Ihr Programm soll in dieser Aufgabe doppelte Einträge aus einer
 *  Liste von Matrikelnummern herausfiltern. Manche Studenten hatten
 *  sich bei der Anmeldung zu einer Prüfung versehentlich mehrfach
 *  eingetragen.
 *
 *  Lesen Sie zuerst eine Reihe von Matrikelnummern (Ganzzahlen) ein,
 *  bis der Benutzer eine 0 eingibt. Diese Reihe (ohne die Null) ist
 *  dann die Liste der Studierenden; es sind maximal 700
 *  Einträge. Fordern Sie den Benutzer jeweils mit dem Text
 *
 *    "Matrikelnummer: "
 *
 *  zur Eingabe auf.
 *
 *  Geben Sie diese Liste dann wieder in derselben Reihenfolge aus,
 *  wobei Sie bereits einmal ausgegebene Matrikelnummern kein zweites
 *  Mal ausgeben. Jede Matrikelnummer soll dabei alleine in einer
 *  eigenen Zeile stehen.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int matrikelnummer[700];
	int input;
	int doubleflag = 0;

	for (int i = 0; i < 700; i++) {
		printf("Matrikelnummer: ");
		scanf("%d", &input);
		if (input == 0) {
			matrikelnummer[i] = input;
			break;
		}
		else
			matrikelnummer[i] = input;
	}
	for (int i = 0; i < 700; i++) {
		if (matrikelnummer[i] == 0)
			break;
		else {
			for (int j = 0; j < i; j++) {
				if (matrikelnummer[i] == matrikelnummer[j]) {
					doubleflag = 1;
					break;
				}
				else
					doubleflag = 0;
			}
			if (doubleflag)
				continue;
			else
				printf("%d\n", matrikelnummer[i]);
		}
	}
}
