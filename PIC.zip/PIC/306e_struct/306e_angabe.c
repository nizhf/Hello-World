/*********************************************************************
 *
 *  Aufgabe 306e
 *
 *  Ergänzen Sie das gegebene Programm um die Verarbeitung für den
 *  Vornamen und die Emailadresse, indem Sie die folgenden Änderungen
 *  durchführen:
 *
 *   1. Fügen Sie in struct Student eine Variable vorname, die eine
 *      Zeichenkette mit maximal 20 Zeichen aufnehmen kann, und eine
 *      Variable email ein, die eine Zeichenkette mit maximal 50
 *      Zeichen aufnehmen kann (die Emailadresse des Studenten).
 *
 *   2. Fragen Sie vor dem Nachnamen den Vornamen mit dem Text
 *
 *        "Vorname: "
 *
 *      ab und speichern Sie die Eingabe in die Komponente vorname der
 *      Variablen stud. Stellen Sie dabei sicher, dass Ihr Programm
 *      maximal 20 Zeichen vom Benutzer einliest.
 *
 *   3. Fragen Sie nach dem Nachnamen die Emailadresse mit dem Text
 *
 *        "Email: "
 *
 *      ab und speichern Sie die Eingabe in die Komponente email der
 *      Variablen stud. Stellen Sie dabei sicher, dass Ihr Programm
 *      maximal 50 Zeichen vom Benutzer einliest.
 *
 *   4. Ändern Sie die Ausgabe der Email zuletzt so ab, dass sie die
 *      Formatzeichenkette
 *
 *        "An: %s\n"
 *        "\n"
 *        "Hallo %s %s,\n"
 *				"\n"
 *        "vielen Dank fuer Ihre Anmeldung zur Tutorenstunde "
 *        "von Programmieren in C.\n"
 *        "\n"
 *        "Sie wurden fuer den Termin %i eingetragen. Bei Fragen "
 *        "wenden Sie sich bitte an pic@ldv.ei.tum.de oder "
 *        "die Uebungsbetreuer.\n"
 *        "\n"
 *        "Das LDV GIP Team.\n"
 *
 *      verwendet, wobei die Variablen in der Reihenfolge email,
 *      vorname, nachname und termin eingefügt werden müssen.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	/* Datentyp für alle Daten zu einem Studenten (Datensatz) */
	struct Student
	{
		char nachname[21];
		int termin;			/* Nummer der Tutorübung (1-8) */
		char vorname[21];
		char email[51];
	};

	/* Variable, die die Daten zu einem Studenten (Datensatz) speichert.
		(Vom Datentyp struct Student) */
	struct Student stud;


	/* Daten des Studenten einlesen und überprüfen */
	printf("Vorname: ");
	scanf("%20s", stud.vorname);
	printf("Nachname: ");
	scanf("%20s", stud.nachname);
	printf("Email: ");
	scanf("%50s", stud.email);

	printf("Terminnummer der Tutorübung: ");
	scanf("%i", &stud.termin);
	if (stud.termin < 1 || stud.termin > 8)
	{
		printf("Bitte wählen Sie eine Terminnummer zwischen 1 und 8.\n");
		return 1;
	}


	/* Email an den Studenten zur Bestätigung senden */
	printf("\n\nEmail: \n");
	printf("------\n\n");
	printf("An: %s\n"
				"\n"
				"Hallo %s %s,\n"
				"\n"
				"vielen Dank fuer Ihre Anmeldung zur Tutorenstunde "
				"von Programmieren in C.\n"
				"\n"
				"Sie wurden fuer den Termin %i eingetragen. Bei Fragen "
				"wenden Sie sich bitte an pic@ldv.ei.tum.de oder "
				"die Uebungsbetreuer.\n"
				"\n"
				"Das LDV GIP Team.\n",
				stud.email, stud.vorname, stud.nachname, stud.termin);
}
