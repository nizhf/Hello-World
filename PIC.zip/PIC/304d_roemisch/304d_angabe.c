/*********************************************************************
 *
 *  Aufgabe 304d
 *
 *  Ihr Programm soll eine römische Zahl in eine arabische Zahl
 *  übersetzen. Lesen Sie dazu eine Zeichenfolge mit einer maximalen
 *  Länge von 15 Zeichen ein. Benutzen Sie hierfür den Text
 *
 *    "Geben Sie bitte eine roemische Zahl ein: "
 *
 *  Berechnen Sie nun die Dezimaldarstellung, wobei Sie Groß- und
 *  Kleinschreibung gleichermaßen berücksichtigen. Geben Sie
 *  anschließend die Zahl in einer eigenen Zeile mit dem Text
 *
 *    "Die arabische Zahl lautet x."
 *
 *  aus. x ist eine einfache ganze Zahl. Sollten Sie auf ein
 *  ungültiges Zeichen stoßen, brechen Sie ihr Programm ohne Ausgabe
 *  ab. Ihr Programm muss aber nicht erkennen, ob die eingegebene Zahl
 *  allen syntaktischen Regeln für römische Zahlen entspricht.
 *
 *  Beachten Sie bitte die Hinweise zu römischen Zahlen auf dem
 *  Arbeitsblatt.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	char rom[16];
	int num = 0;
	int valid = 1;

	printf("Geben Sie bitte eine roemische Zahl ein: ");
	scanf("%15s", rom);

	for (int i = 0; i < 16; i++) {
		if (rom[i] == 'M' || rom[i] == 'm')
			num += 1000;
		else if (rom[i] == 'D' || rom[i] == 'd')
			num += 500;
		else if (i < 15 && (rom[i] == 'C' || rom[i] == 'c') && (rom[i + 1] == 'D' || rom[i + 1] == 'd' || rom[i + 1] == 'M' || rom[i + 1] == 'm'))
			num -= 100;
		else if (rom[i] == 'C' || rom[i] == 'c')
			num += 100;
		else if (rom[i] == 'L' || rom[i] == 'l')
			num += 50;
		else if (i < 15 && (rom[i] == 'X' || rom[i] == 'x') && (rom[i + 1] == 'L' || rom[i] == 'l' || rom[i + 1] == 'C' || rom[i] == 'c'))
			num -= 10;
		else if (rom[i] == 'X' || rom[i] == 'x')
			num += 10;
		else if (rom[i] == 'V' || rom[i] == 'v')
			num += 5;
		else if (i < 15 && (rom[i] == 'I' || rom[i] == 'i') && (rom[i + 1] == 'V' || rom[i] == 'v' || rom[i + 1] == 'X' || rom[i] == 'x'))
			num--;
		else if (rom[i] == 'I' || rom[i] == 'i')
			num++;
		else if (rom[i] == '\0')
			break;
		else {
			valid = 0;
			break;
		}
	}
	if (valid)
		printf("Die arabische Zahl lautet %d.\n", num);
}
