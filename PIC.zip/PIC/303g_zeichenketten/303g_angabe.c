/*********************************************************************
 *
 * Aufgabe 303g
 *
 * Modifizieren Sie unten stehendes Programm so, dass es nur die vom
 * Benutzer eingebenen Zeichen zeichenweise (mit der
 * Formatzeichenkette " %c ") ausgibt. Lösen Sie auch diese Aufgabe
 * ohne die Funktion strlen.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	char eingabe[21];
	int i = 0;


	printf("Bitte geben Sie einen Text ein: ");
	scanf("%20s", eingabe);

	for(i = 0; i < 21; ++i)
	{
		if (eingabe[i] == '\0')
			break;
		printf(" %c ", eingabe[i]);
	}
	printf("\n");
}
