/*********************************************************************
 *
 *  Aufgabe 2d
 *
 *  Implementieren Sie in dieser Aufgabe die Funktion dez2bin. Diese
 *  Funktion soll das Bitmuster einer ganzen Zahl (int) in eine
 *  Zeichenkette schreiben. Wir haben den Algorithmus im Folgenden
 *  bereits in verbalisierter Form vorgegeben.
 *
 *  Für das Verständnis des Algorithmus ist die Anordnung der Bits
 *  wichtig. Wir betrachten nur den Betrag der Zahl, so dass uns nur
 *  die ersten 31 Bits interessieren. Das höherwertigste Bit des
 *  Betrags soll dabei Bit 30 und das niederwertigste Bit soll Bit 0
 *  sein. Bit 30 sei bildlich ganz links und Bit 0 ganz rechts
 *  angeordnet. Damit lässt sich folgender Algorithmus formulieren:
 *
 *  FÜR JEDES Bit ab Bit 30 bis Bit 0 in der Variablen "dezimal":
 *
 *    Verschiebe das Bitmuster der Variablen "dezimal" so, dass das
 *    aktuelle Bit auf die Position 0 (ganz rechts) gelangt. Das
 *    Ergebnis wird in der neuen Variablen "aktBit" gespeichert.
 *
 *    Führe eine bitweise UND-Operation der Variablen "aktBit" mit
 *    0x00000001 aus. Daraus ergibt sich eine neue Zahl, die wiederum
 *    in "aktBit" gespeichert wird.
 *
 *    Wandle nun den Wert von aktBit (0 oder 1) in sein entsprechendes
 *    Zeichen ('0' oder '1') um. Speichere dieses Zeichen an der
 *    passenden Stelle in dem Feld binaerString.
 *
 *  ENDE FÜR JEDES
 *
 *  Schließen Sie das Feld so ab, dass sich ein korrekter C-String
 *  ergibt.
 *
 *  Füllen Sie in dieser Aufgabe lediglich die Zeichenkette
 *  binaerString. Schreiben Sie keine eigene Funktion main! Wir haben
 *  diese bereits selbst geschrieben. Unsere Funktion übernimmt auch
 *  alle nötigen Ein- und Ausgaben.
 *
 *********************************************************************/

/* 
 * dezimal:      die zu konvertierende Zahl
 * binaerString: die binäre Darstellung von dezimal
 *               Länge 32: 31 bit + '\0' 
 */

void dez2bin(int dezimal, char binaerString[32])
{
	
}
