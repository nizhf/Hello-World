/*********************************************************************
*
*  Aufgabe 102d
*
*  Schreiben Sie ein Programm, dass die unten stehende Ausgabe
*  erzeugt. Dabei sollen Sie den Ausgabewert als Konstante durch
*  einen Platzhalter in der Formatbeschreibung einbinden
*  (z.B. printf("%.1lf\n", 1.0);). Lösen Sie die Aufgabe also mit
*  Konstanten, aber ohne Variablen und benutzen Sie Platzhalter in
*  der Formatbeschreibung.
*
*    "42"
*    "14.21"
*    "A"
*
*  Wieder sind die äußersten Anführungszeichen in jeder Zeile kein
*  Teil der Ausgabe, sondern die Begrenzung des auszugebenden Textes.
*
*********************************************************************/


#include <stdio.h>


int main()
{
	printf("%d\n", 42);
	printf("%.2f\n", 14.21);
	printf("%c\n", 'A');
}
