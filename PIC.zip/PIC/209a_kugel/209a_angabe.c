/*********************************************************************
 *
 *  Aufgabe 209a
 *
 *  Erweitern Sie Ihr Programm zur Berechnung von Kugeloberfläche und
 *  -volumen so, dass solange weitere Kugeln berechnet werden können,
 *  bis der Radius 0.0 eingegeben wird. Geben Sie hierfür zu Anfang
 *  Ihres Programms folgenden Hinweis für den Benutzer gefolgt von
 *  einer Leerzeile aus:
 *
 *    "Geben Sie als Radius 0 ein, um das Programm zu beenden."
 *
 *********************************************************************/


#include <stdio.h>
#include <math.h>
#define eps 1e-8


int main()
{
	const double PI = 3.14159;  /* Kreiskonstante pi */
	double r = 5.0;             /* Radius der Kugel */
	double A = 0.0;             /* Oberfläche der Kugel */
	double V = 0.0;

	printf("Geben Sie als Radius 0 ein, um das Programm zu beenden.\n\n");
 	/* Radius vom Benutzer einlesen */
	printf("Kugelradius: ");
	scanf("%lf", &r);
	while (fabs(r - 0.0) > eps) {
		/* Berechnungen durchführen */
		A = 4.0 * PI * r * r;
		V = 4.0 / 3.0 * PI * r * r * r;

		/* Ausgabe des Ergebnisses */
		printf("Radius: %.2lf\n", r);
		printf("Oberflaeche: %.2lf\n", A);
		printf("Volumen: %.2lf\n", V);

		printf("Kugelradius: ");
		scanf("%lf", &r);
	}


}
