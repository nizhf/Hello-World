/*********************************************************************
 *
 * Aufgabe 205j
 *
 * Das gegebene Programm gibt eine Zahlenreihe aus. Es zeigt eine
 * typische Verwendung der for-Schleife.
 *
 * Modifizieren Sie unten stehenden Code so, dass er die Zahlen in
 * umgekehrter Reihenfolge ausgibt.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int i = 0;
	int benutzerZahl = 0;


	printf("Ganze Zahl: ");
	scanf("%i", &benutzerZahl);

	for(i = benutzerZahl - 1; i >= 0; i--)
	{
		printf(" %2i", i);
	}

	printf("\n");
}
