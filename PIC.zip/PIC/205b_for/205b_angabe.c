/*********************************************************************
 *
 *  Aufgabe 205b
 *
 *  Das gegebene Programm gibt eine Zahlenreihe aus. Es zeigt eine
 *  typische Verwendung der for-Schleife.
 *
 *  Modifizieren Sie den Code nun so, dass er die Zahlen von der
 *  Variablen "benutzerZahl" bis 33 ausgibt. Die vom Benutzer
 *  eingegebene Zahl ist dabei immer kleiner oder gleich 33. Sie
 *  brauchen das nicht zu prüfen.
 *
 *********************************************************************/


#include <stdio.h>


int main()
{
	int i = 0;
	int benutzerZahl = 0;


	printf("Ganze Zahl: ");
	scanf("%i", &benutzerZahl);

	for(i = benutzerZahl; i < 34; ++i)
	{
		printf(" %2i", i);
	}

	printf("\n");
}
